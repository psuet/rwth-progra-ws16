public enum Material{
	Wood,
	Plastic,
	Metal,
	Stone,
	Concrete,
	ReinforcedConcrete;
}